package com.tandf.javateams.service;

public interface ITeamsService {

    void SendMessage(String message);
}

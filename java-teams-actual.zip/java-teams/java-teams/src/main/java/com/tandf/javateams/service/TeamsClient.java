package com.tandf.javateams.service;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.springframework.beans.factory.annotation.Value;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;

public class TeamsClient {


    public void sendFile(String filePath) throws IOException {
        File file = new File(filePath);
        if (!file.exists()) {
            throw new FileNotFoundException("File not found: " + filePath);
        }

        byte[] fileContent = Files.readAllBytes(Path.of(filePath));

        String base64EncodedContent = Base64.getEncoder().encodeToString(fileContent);


        String jsonPayload = createCardPayload(getFileName(filePath), getFileExtension(filePath), base64EncodedContent);

        sendPayloadToTeams(jsonPayload);

    }

    private String createCardPayload(String fileName, String fileType, String base64Content) {
        return "{\n" +
                "  \"@type\": \"MessageCard\",\n" +
                "  \"@context\": \"http://schema.org/extensions\",\n" +
                "  \"themeColor\": \"0076D7\",\n" +
                "  \"summary\": \"File Attachment\",\n" +
                "  \"sections\": [\n" +
                "    {\n" +
                "      \"activityTitle\": \"File Attachment\",\n" +
                "      \"facts\": [\n" +
                "        {\n" +
                "          \"name\": \"File Name\",\n" +
                "          \"value\": \"" + fileName + "\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"name\": \"File Type\",\n" +
                "          \"value\": \"" + fileType + "\"\n" +
                "        }\n" +
                "      ],\n" +
                "      \"potentialAction\": [\n" +
                "        {\n" +
                "          \"@type\": \"OpenUri\",\n" +
                "          \"name\": \"Download File\",\n" +
                "          \"targets\": [\n" +
                "            {\n" +
                "              \"os\": \"default\",\n" +
                "              \"uri\": \"data:application/octet-stream;base64," + base64Content + "\"\n" +
                "            }\n" +
                "          ]\n" +
                "        }\n" +
                "      ]\n" +
                "    }\n" +
                "  ]\n" +
                "}";
    }

    private byte[] readFileContent(File file) throws IOException {
        try (InputStream inputStream = new FileInputStream(file)) {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            return outputStream.toByteArray();
        }
    }

    private String getFileName(String filePath) {
        return Path.of(filePath).getFileName().toString();
    }

    private String getFileExtension(String filePath) {
        return Path.of(filePath).toString().substring(filePath.lastIndexOf('.') + 1);
    }

    private String getFileType(String fileName) {
        int lastDotIndex = fileName.lastIndexOf(".");
        if (lastDotIndex != -1 && lastDotIndex < fileName.length() - 1) {
            return fileName.substring(lastDotIndex + 1);
        }
        return "";
    }

    private String encodeBase64(byte[] data) {
        return java.util.Base64.getEncoder().encodeToString(data);
    }

    private void sendPayloadToTeams(String jsonPayload) throws IOException {
        URL url = new URL("https://triconindia.webhook.office.com/webhookb2/f8cca740-0496-490e-8a0c-d8253106807a@6ba04439-8b0e-43ee-ad26-c2ac9ef9e765/IncomingWebhook/ca73d90db00049dc9577024e88fe640a/2d2240ea-4049-4db9-bdfa-13e380fc0185");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setDoOutput(true);
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "application/json");

        try (OutputStream outputStream = connection.getOutputStream();
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"))) {
            writer.write(jsonPayload);
        }

        int responseCode = connection.getResponseCode();
        if (responseCode != HttpURLConnection.HTTP_OK) {
            throw new IOException("Failed to send file to Teams. Response code: " + responseCode);
        }
    }
}

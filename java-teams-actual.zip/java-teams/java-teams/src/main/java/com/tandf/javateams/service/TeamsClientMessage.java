package com.tandf.javateams.service;


import com.google.gson.Gson;
import com.tandf.javateams.model.TeamsMessageModel;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class TeamsClientMessage {


    public void sendMessageToTeams(String webhookUrl, String message) throws IOException {
        try {

            URL url = null;
            try {
                url = new URL(webhookUrl);
            } catch (MalformedURLException ex) {
                throw new RuntimeException(ex);
            }


            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            try {
                connection.setRequestMethod("POST");
            } catch (ProtocolException ex) {
                throw new RuntimeException(ex);
            }
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            String payload = "{\"text\": \"" + message + "\"}";


            try (OutputStream outputStream = connection.getOutputStream()) {
                byte[] input = payload.getBytes(StandardCharsets.UTF_8);
                try {
                    outputStream.write(input, 0, input.length);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }

            int responseCode = 0;
            try {
                responseCode = connection.getResponseCode();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
            System.out.println("Response Code: " + responseCode);


            connection.disconnect();
    } catch (RuntimeException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

        public static void main(String[] args) throws IOException {
            TeamsClientMessage teamsClientMessage = new TeamsClientMessage();
            String webhookUrl = "https://triconindia.webhook.office.com/webhookb2/f8cca740-0496-490e-8a0c-d8253106807a@6ba04439-8b0e-43ee-ad26-c2ac9ef9e765/IncomingWebhook/ca73d90db00049dc9577024e88fe640a/2d2240ea-4049-4db9-bdfa-13e380fc0185";
            String message = "Hello, Teams!";

            teamsClientMessage.sendMessageToTeams(webhookUrl, message);
        }
    }






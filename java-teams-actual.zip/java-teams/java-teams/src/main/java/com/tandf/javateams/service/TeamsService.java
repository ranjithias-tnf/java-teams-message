package com.tandf.javateams.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

@Service
public class TeamsService implements ITeamsService{

    @Value("${url}")
    private String webhookUrl;
    @Override
    public void SendMessage(String message) {
        //String message = "Teams Message from Java";
        try {

            URL url = new URL(webhookUrl);


            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            String payload = "{\"text\": \"" + message + "\"}";


            try (OutputStream outputStream = connection.getOutputStream()) {
                byte[] input = payload.getBytes(StandardCharsets.UTF_8);
                outputStream.write(input, 0, input.length);
            }


            int responseCode = connection.getResponseCode();
            System.out.println("Response Code: " + responseCode);


            connection.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

package com.tandf.javateams.service;


import java.io.File;
import java.io.IOException;


import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;

public class TeamsClient1 {
    public void sendFileToChannel(String webhookUrl, String teamId, String channelId, String filePath) throws IOException, InterruptedException {
        HttpClient httpClient = HttpClient.newHttpClient();

        byte[] fileContent = Files.readAllBytes(Path.of(filePath));
        String base64Content = Base64.getEncoder().encodeToString(fileContent);

        String jsonPayload = String.format("{\"title\":\"%s\",\"type\":\"%s\",\"content\":\"%s\"}",
                new File(filePath).getName(), getFileExtension(filePath), base64Content);


        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(String.format("%s/teams/%s/channels/%s/messages", webhookUrl, teamId, channelId)))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonPayload))
                .build();


        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());


        System.out.println(response.statusCode());
        System.out.println(response.body());
    }

    private String getFileExtension(String filePath) {
        int dotIndex = filePath.lastIndexOf(".");
        if (dotIndex > 0 && dotIndex < filePath.length() - 1) {
            return filePath.substring(dotIndex + 1);
        }
        return "";
    }
}
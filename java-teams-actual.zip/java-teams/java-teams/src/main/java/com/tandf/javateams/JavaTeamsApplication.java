package com.tandf.javateams;

import com.tandf.javateams.controller.TeamsController;
import com.tandf.javateams.service.TeamsClient;
import com.tandf.javateams.service.TeamsClient1;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.io.File;
import java.io.IOException;

@SpringBootApplication
@EnableAsync
public class JavaTeamsApplication {
	public static void main(String[] args) throws IOException {
		SpringApplication.run(JavaTeamsApplication.class, args);
		System.out.println("*hello main*");
		String filePath = "something.txt";

		File file = new File(filePath);

		TeamsClient teamsClient = new TeamsClient();
		//TeamsClient1 teamsClient1 =new TeamsClient1();
		/*try {
			//teamsClient1.sendFileToChannel("https://triconindia.webhook.office.com/webhookb2/f8cca740-0496-490e-8a0c-d8253106807a@6ba04439-8b0e-43ee-ad26-c2ac9ef9e765/IncomingWebhook/ca73d90db00049dc9577024e88fe640a/2d2240ea-4049-4db9-bdfa-13e380fc0185", "19%3aYHtQa-WLUla-jnu8ewdpIo_sLFVf8faZE7qHUd8TnrE1%40thread.tacv2", "19%3aYHtQa-WLUla-jnu8ewdpIo_sLFVf8faZE7qHUd8TnrE1%40thread.tacv2", filePath);
			teamsClient.sendFile(filePath);
			System.out.println("File sent successfully.");
		} catch (IOException e) {
			System.out.println("Error occurred while sending the file: " + e.getMessage());
		}*/

	}

	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}

}
